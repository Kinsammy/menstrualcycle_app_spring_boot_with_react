package com.example.mentrual_cycle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentrualCycleApplicationTests {

	@Test
	void contextLoads() {
	}

}
